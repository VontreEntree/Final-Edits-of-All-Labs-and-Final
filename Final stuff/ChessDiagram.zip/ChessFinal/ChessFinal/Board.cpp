#include "stdafx.h"
#include "Board.h"


Board::Board()
{
}


Board::~Board()
{
}

void Board::displayBoard()
{
	cout << "\n\n";
	cout << "    a   b   c   d   e   f   g   h\n";
	cout << "  +-------------------------------+\n";
	for (size_t i = 0; i < 8; ++i) {
		switch (i) {
		case 0: cout << "1 "; break;
		case 1: cout << "2 "; break;
		case 2: cout << "3 "; break;
		case 3: cout << "4 "; break;
		case 4: cout << "5 "; break;
		case 5: cout << "6 "; break;
		case 6: cout << "7 "; break;
		case 7: cout << "8 "; break;
		}
		cout << "|";
		for (size_t j = 0; j < 8; ++j) {
			cout << displayPiece(board[i][j]);
			cout << "|";
			if (j == 7) cout << "\n";
		}
	cout << "  +-------------------------------+\n";
	}
	cout << "Taken pieces: " << takenPiecesList() << "\n";
}
void Board::logTakenPiece(int piece)
{
	string piece_str = displayPiece(piece, 1);
	if (piece_str.length() > 0)
	{
		if (taken_pieces.length() > 0)
		{
			taken_pieces = taken_pieces + ",";
			taken_pieces = taken_pieces + displayPiece(piece);
		}
	}
}

string Board::displayPiece(int piece = 0, int supress_blank = 0)
{
	string str = "";
	if (piece > 0) { // White piece
		if (supress_blank == 1) {
			switch (piece) {
			case rook:    str = "r"; break;
			case knight:  str = "k"; break;
			case bishop:  str = "b"; break;
			case queen:   str = "Q"; break;
			case king:    str = "K"; break;
			case pawn:    str = "p"; break;
			}
		}
		else {
			switch (piece) {
			case rock:    str = " r "; break;
			case knight:  str = " k "; break;
			case bishop:  str = " b "; break;
			case queen:   str = " Q "; break;
			case king:    str = " K "; break;
			case pawn:    str = " p "; break;
			}
		}
	}
	else {
		if (piece < 0) {
			switch (-piece) {
			case rock:    str = "(r)"; break;
			case knight:  str = "(k)"; break;
			case bishop:  str = "(b)"; break;
			case queen:   str = "(Q)"; break;
			case king:    str = "(K)"; break;
			case pawn:    str = "(p)"; break;
			}
		}
		else {
			if (supress_blank == 1) return "";
			str = "   ";
		}
	}
	return str;
}
string Board::takenPiecesList()
{
	string list = taken_pieces;
	if (list.length() == 0)
	{
		list = "N/A";
	}

	return list;
}