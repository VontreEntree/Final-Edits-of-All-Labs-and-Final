#pragma once
#include "Board.h"
class Pieces : public Board
{
public:
	Pieces();
	~Pieces();

	virtual int move();
};

