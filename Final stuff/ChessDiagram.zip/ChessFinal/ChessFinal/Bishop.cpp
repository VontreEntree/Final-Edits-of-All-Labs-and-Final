#include "stdafx.h"
#include "Bishop.h"


Bishop::Bishop()
{
}


Bishop::~Bishop()
{
}

int Bishop::move(int ox, int oy, int dx, int dy)
{
	int source = board[oy][ox];
	int target = board[dy][dx];

	if (abs(dy - oy) == abs(dx - ox)) { // Moving diagonally
		if (dy>oy) { // South
			int column = min(dx, ox) + 1;
			for (size_t row = oy + 1; row < (unsigned)dy; ++row) {
				if (board[row][column] != 0) return 0;
				column++;
			}
			return 1;
		}
		if (dy<oy && dx>ox) { // North
			int column = min(dx, ox) + 1;
			for (size_t row = oy + 1; row < (unsigned)dy; ++row) {
				if (board[row][column] != 0) return 0;
				column++;
			}
			return 1;
		}
	}
	return 0;
}