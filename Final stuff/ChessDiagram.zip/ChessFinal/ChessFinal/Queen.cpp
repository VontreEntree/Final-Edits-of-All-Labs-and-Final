#include "stdafx.h"
#include "Queen.h"


Queen::Queen()
{
}


Queen::~Queen()
{
}

int Queen::move(int ox, int oy, int dx, int dy)
{
	int source = board[oy][ox];
	int target = board[dy][dx];

	if (abs(dy - oy) == abs(dx - ox)) { // Moving diagonally
		if (dy>oy) { // South
			int column = min(dx, ox) + 1;
			for (size_t row = oy + 1; row < (unsigned)dy; ++row) {
				if (board[row][column] != 0) return 0;
				column++;
			}
			return 1;
		}
		if (dy<oy && dx>ox) { // North
			int column = min(dx, ox) + 1;
			for (size_t row = oy + 1; row < (unsigned)dy; ++row) {
				if (board[row][column] != 0) return 0;
				column++;
			}
			return 1;
		}
	}
	if (dy == oy || dx == ox) { // Moving straight
		if (dx == ox) { // Moving vertically
			if (dy>oy) { // Downards
				for (size_t row = (unsigned)(oy + 1); row < (unsigned)dy; ++row) {
					if (board[row][dx] != 0) return 0;
				}
			}
			else { // Upwards
				for (size_t row = (unsigned)dy; row < (unsigned)(oy - 1); ++row) {
					if (board[row][dx] != 0) return 0;
				}
			}
			return 1;
		}
		if (dy == oy) { // Moving horizontally
			if (dx>ox) { // Rightwards
				for (size_t column = (unsigned)(ox + 1); column < (unsigned)dy; ++column) {
					if (board[dy][column] != 0) return 0;
				}
			}
			if (dx<ox) { // Leftwards
				for (size_t column = (unsigned)dx; column < (unsigned)(ox - 1); ++column) {
					if (board[dy][column] != 0) return 0;
				}
			}
			return 1;
		}
	}
	return 0;
}