#include "stdafx.h"
#include "Rook.h"


Rook::Rook()
{
}


Rook::~Rook()
{
}

int Rook::move(int ox, int oy, int dx, int dy)
{
	int source = board[oy][ox];
	int target = board[dy][dx];

	if (dx == ox)//Moving Vertically
	{
		if (dy > oy)//Downwards
		{
			for (size_t row = (unsigned)(oy + 1); row < (unsigned)dy; ++row)
			{
				if (board[row][dx] != 0)
				{
					return 0;
				}
				else // Upwards
				{
					for (size_t row = (unsigned)dy; row < (unsigned)(oy - 1); ++row)
					{
						if (board[row][dx] != 0)
						{
							return 0;
						}
					}
				}
			}
			
		}
		return 1;
	}
	if (dy == oy) // Moving Horizontally
	{
		if (dx > ox) // To the right
		{
			for (size_t column = (unsigned)(ox + 1); column < (unsigned)dy; ++column)
			{
				if (board[dy][column] != 0)
				{
					return 0;
				}
			}
		}
		if (dx < ox) // To the left
		{
			for (size_t column = (unsigned)dx; column < (unsigned)(ox - 1); ++column)
			{
				if (board[dy][column] != 0)
				{
					return 0;
				}
			}
		}
		return 1;
	}
	return 0;
}