#pragma once
#include "iostream"
#include "fstream"
#include "string"
#include "vector"
#include "math.h"
#include "cstdlib"
#include "sstream"
#include "Player.h"
#include "Pieces.h"
using namespace std;
class Board : public Player, public Pieces
{
public:
	Board();
	~Board();

	Pieces pcs = Pieces();

	int board[8][8];
	int status = 0;

	string taken_pieces = "";

	void displayBoard();
	void logTakenPiece(int);

	string displayPiece(int, int);
	string takenPiecesList();
};

