#include "stdafx.h"
#include "King.h"


King::King()
{
}


King::~King()
{
}

int King::move(int ox, int oy, int dx, int dy)
{
	int source = board[oy][ox];
	int target = board[dy][dx];

	if (abs(dy - oy) <= 1 && abs(dx - ox) <= 1) return 1;
	// TODO: Check for castling
	return 0;
}