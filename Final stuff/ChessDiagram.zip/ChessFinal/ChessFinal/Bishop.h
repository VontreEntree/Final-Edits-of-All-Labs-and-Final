#pragma once
#include "Pieces.h"
using namespace std;
class Bishop : public Pieces
{
public:
	Bishop();
	~Bishop();

	int bishop = 4;

	int move(int, int, int, int);
};

