#include "stdafx.h"
#include "Player.h"


Player::Player()
{
}


Player::~Player()
{
}

int Player::oppositePlayer()
{
	if (current_player == 1)
	{
		return 2;
	}
	return 1;
}

int Player::validMove(int ox, int oy, int dx, int dy)
{
	int source = board[oy][ox];
	int target = board[dy][dx];

	switch (abs(source)) {
		//Pawn
	case 1:
	case -1:
		Pawn::move();
		break;
		// Rock
	case 2:
		Rock::move();
		break;
		// Knight
	case 3:
		Knight::move();
		break;
		// Bishop
	case 4:
		Bishop::move();
		break;
		// Queen
	case 5:
		Queen::move();
		break;
		// King
	case 6:
		King::move();
		break;
	}
	return 0;
}

string Player::currentPlayerColor()
{
	if (current_player == 1) return "White";
	return "Black";
}

string Player::oppositePlayerColor() {
	if (current_player == 1) return "Black";
	return "White";
}