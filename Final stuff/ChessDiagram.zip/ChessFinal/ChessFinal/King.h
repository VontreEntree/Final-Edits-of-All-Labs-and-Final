#pragma once
#include "Pieces.h"
using namespace std;
class King : public Pieces
{
public:
	King();
	~King();

	int king = 6;

	int move(int, int, int, int);
};

