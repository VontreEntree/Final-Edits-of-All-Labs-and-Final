#pragma once
#include "Pieces.h"
using namespace std;
class Pawn : public Pieces
{
public:
	Pawn();
	~Pawn();

	int pawn = 1;

	int move(int, int, int, int);
};

