#include "stdafx.h"
#include "Knight.h"


Knight::Knight()
{
}


Knight::~Knight()
{
}

int Knight::move(int ox, int oy, int dx, int dy)
{
	int source = board[oy][ox];
	int target = board[dy][dx];

	if ((abs(dy - oy) == 2 && abs(dx - ox) == 1) || (abs(dx - ox) == 2 && abs(dy - oy) == 1)) {
		return 1;
	}
	return 0;
}