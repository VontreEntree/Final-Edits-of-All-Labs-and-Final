#include "stdafx.h"
#include "ChessGame.h"


ChessGame::ChessGame()
{
}


ChessGame::~ChessGame()
{
}

void ChessGame::reset()
{
	// Normal board setup
	board[0][0] = rock;
	board[0][1] = knight;
	board[0][2] = bishop;
	board[0][3] = queen;
	board[0][4] = king;
	board[0][5] = bishop;
	board[0][6] = knight;
	board[0][7] = rock;
	board[1][0] = pawn;
	board[1][1] = pawn;
	board[1][2] = pawn;
	board[1][3] = pawn;
	board[1][4] = pawn;
	board[1][5] = pawn;
	board[1][6] = pawn;
	board[1][7] = pawn;
	board[2][0] = 0;
	board[2][1] = 0;
	board[2][2] = 0;
	board[2][3] = 0;
	board[2][4] = 0;
	board[2][5] = 0;
	board[2][6] = 0;
	board[2][7] = 0;
	board[3][0] = 0;
	board[3][1] = 0;
	board[3][2] = 0;
	board[3][3] = 0;
	board[3][4] = 0;
	board[3][5] = 0;
	board[3][6] = 0;
	board[3][7] = 0;
	board[4][0] = 0;
	board[4][1] = 0;
	board[4][2] = 0;
	board[4][3] = 0;
	board[4][4] = 0;
	board[4][5] = 0;
	board[4][6] = 0;
	board[4][7] = 0;
	board[5][0] = 0;
	board[5][1] = 0;
	board[5][2] = 0;
	board[5][3] = 0;
	board[5][4] = 0;
	board[5][5] = 0;
	board[5][6] = 0;
	board[5][7] = 0;
	board[6][0] = -pawn;
	board[6][1] = -pawn;
	board[6][2] = -pawn;
	board[6][3] = -pawn;
	board[6][4] = -pawn;
	board[6][5] = -pawn;
	board[6][6] = -pawn;
	board[6][7] = -pawn;
	board[7][0] = -rock;
	board[7][1] = -knight;
	board[7][2] = -bishop;
	board[7][3] = -queen;
	board[7][4] = -king;
	board[7][5] = -bishop;
	board[7][6] = -knight;
	board[7][7] = -rock;
	current_player = 1;
	turn_counter = 1;
	status = 0;
	taken_pieces = "";
}

void ChessGame::displayHelp()
{
	cout << "\n\n";
	cout << "When asked for a move, please enter a move in the following fasion: from>to. This means, that if you want to move from a1 to a2 then you should write a1>a2.\n";
	cout << "If you get the warning: Illegal move it means that you entered a move that's either impossible with the selected piece or you't trying to take one of your own pieces or you'r trying to move out of the board.\n";
	cout << "Typing reset will reset the game back to starting position. Typing display will redraw the board. Typing exit or quit will exit the game.\n";
}

void ChessGame::displayGameInformation()
{
	cout << "This is a game of chess to be played between to humans. To get help with movements and such, type 'help'.\n";
}

string ChessGame::getLetter(int column)
{
	switch (column) {
	case 0: return "a"; break;
	case 1: return "b"; break;
	case 2: return "c"; break;
	case 3: return "d"; break;
	case 4: return "e"; break;
	case 5: return "f"; break;
	case 6: return "g"; break;
	}
	return "n/a";
}

int ChessGame::getNumber(string letter)
{
	if (letter == "a") return 0;
	if (letter == "b") return 1;
	if (letter == "c") return 2;
	if (letter == "d") return 3;
	if (letter == "e") return 4;
	if (letter == "f") return 5;
	if (letter == "g") return 6;
	if (letter == "h") return 7;
	return 0;
}

int ChessGame::getMove()
{
	cout << "Turn " << turn_counter << ". " << currentPlayerColor() << ", select a move:";
	string move = "";
	cin >> move;

	// Checks if the move is a command
	if (move == "help") { // Display help
		displayHelp();
		displayBoard();
		return 0;
	}
	if (move == "reset") { // Reset the game
		reset(); displayBoard(); return 0;
	}
	if (move == "display") { // Displays the board
		displayBoard(); return 0;
	}
	if (move == "exit" || move == "quit") exit(1);

	// Splits the move into orgination and destrination and those 
	// into x and y parts
	// TODO: Add validation of the y-coordinate of both the 
	//       destination and the origination. 
	int ox = 0; int oy = 0; int dx = 0; int dy = 0;
	string ox_part = move.substr(0, move.find(">")).substr(0, 1);
	string oy_part = move.substr(0, move.find(">")).substr(1, 1);
	string dx_part = move.substr(move.find(">") + 1, move.length()).substr(0, 1);
	string dy_part = move.substr(move.find(">") + 1, move.length()).substr(1, 1);
	ox = getNumber(ox_part);
	oy = atoi(oy_part.c_str()) - 1;
	dx = getNumber(dx_part);
	dy = atoi(dy_part.c_str()) - 1;

	// Gets the piece in question and moves it
	int source = board[oy][ox];
	int target = board[dy][dx];
	if ((current_player == 1 && (source <= 0 || target > 0)) || (current_player == 2 && (source >= 0 || target < 0)) || !validMove(ox, oy, dx, dy)) {
		cout << "Illegal move\n"; return 0;
	}

	// Moves the piece
	board[oy][ox] = 0;
	board[dy][dx] = source;
	logTakenPiece(target);

	// Checks for win condition
	// Changes the +status+ for the game to the +current_player+
	if (abs(target) == king) {
		status = current_player;
		return 0;
	}

	// Increments the +turn_counter+
	turn_counter++;

	// Changes the turn
	current_player = oppositePlayer();

	// Redraws the board
	displayBoard();

	return 0;
}