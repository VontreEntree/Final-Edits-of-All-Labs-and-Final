#pragma once
#include "Pieces.h"
using namespace std;
class Player : public Pieces
{
public:
	Player();
	~Player();

	int current_player = 1;

	int oppositePlayer();
	int validMove(int, int, int, int);

	string currentPlayerColor();
	string oppositePlayerColor();
};

