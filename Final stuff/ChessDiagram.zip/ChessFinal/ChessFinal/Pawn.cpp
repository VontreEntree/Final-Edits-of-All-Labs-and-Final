#include "stdafx.h"
#include "Pawn.h"


Pawn::Pawn()
{
}


Pawn::~Pawn()
{
}

int Pawn::move(int ox, int oy, int dx, int dy)
{
	int source = board[oy][ox];
	int target = board[dy][dx];

	if (dx == ox && abs(dy - oy) == 1 && target == 0) return 1;
	if (abs(dx - ox) == 1 && abs(dy - oy) == 1 && target != 0) return 1;
	if (current_player == 1 && oy == 1 && abs(oy - dy) == 2 && target == 0) return 1;
	if (current_player == 2 && oy == 6 && abs(oy - dy) == 2 && target == 0) return 1;
}