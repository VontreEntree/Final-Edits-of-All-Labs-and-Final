#include "stdafx.h"
#include "Pieces.h"


Pieces::Pieces()
{
}


Pieces::~Pieces()
{
}
