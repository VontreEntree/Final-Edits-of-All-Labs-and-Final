#pragma once
#include "Board.h"
class ChessGame : public Board
{
public:
	ChessGame();
	~ChessGame();

	int exit_game = 0;
	int turn_counter;

	void reset();
	void displayHelp();
	void displayGameInformation();
	string getLetter(int);
	int getNumber(string);
	int getMove();
};

