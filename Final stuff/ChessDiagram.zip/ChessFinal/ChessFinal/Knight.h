#pragma once
#include "Pieces.h"
using namespace std;
class Knight : public Pieces
{
public:
	Knight();
	~Knight();

	int knight = 3;

	int move(int, int, int, int);
};

