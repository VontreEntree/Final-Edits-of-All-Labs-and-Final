#pragma once
#include "Pieces.h"
using namespace std;
class Rook : public Pieces
{
public:
	Rook();
	~Rook();

	 int rook = 2;

	int move(int, int, int, int);
};

