#pragma once
#include "Pieces.h"
using namespace std;
class Queen : public Pieces
{
public:
	Queen();
	~Queen();

	int queen = 5;

	int move(int, int, int, int);
};

