#include "stdafx.h"
#include "PowerManager.h"


PowerManager::PowerManager()
{
}


PowerManager::~PowerManager()
{
}

void PowerManager::Reboot()
{
	if (isOn == true)
	{
		cout << "Weather Station is now restarting....." << endl;
		isOff = true;
		isOn = false;

		if (isOff == true)
		{
			cout << "Weather Station is now powering up....." << endl;

			isOff = false;
			isOn = true;
		}
	}
	else if (isOff == true)
	{
		cout << "Weather Station must be running" << endl;
	}
}

void PowerManager::PowerOFF()
{
	if (isOn == true)
	{
		cout << "Weather Station is now shutting down....." << endl;

		isOff = true;
		isOn = false;

		DisableUpdate();
	}
	else if (isOff == true)
	{
		cout << "Weather Station must be running" << endl;
	}
	
}

void PowerManager::PowerON()
{
	if (isOff == true)
	{
		cout << "Weather Station is now powering up....." << endl;

		isOff = false;
		isOn = true;

		EnableUpdate();
	}
	else if (isOn == true)
	{
		cout << "Weather Station is already running" << endl;
	}
}

void PowerManager::Suspend()
{

}

void PowerManager::Overload()
{
	
}

void PowerManager::EnableUpdate()
{
	
}

void PowerManager::DisableUpdate()
{

}