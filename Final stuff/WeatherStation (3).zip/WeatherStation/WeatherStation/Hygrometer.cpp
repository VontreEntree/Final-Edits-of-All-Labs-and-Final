#include "stdafx.h"
#include "Hygrometer.h"


Hygrometer::Hygrometer()
{
}


Hygrometer::~Hygrometer()
{
}

void HumidCalc(int dryBulb, int wetBulb)
{
	
}

void SendData()
{

}

void update()
{

}