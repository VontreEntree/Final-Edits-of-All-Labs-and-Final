#pragma once
#include <cstdlib>
#include <iostream>
#include "RainGauge.h"
#include "Thermometer.h"
#include "Anemometer.h"
#include "Barometer.h"
#include "Hygrometer.h"


using namespace std;
class PowerManager : public RainGauge, public Thermometer, public Anemometer, public Barometer, public Hygrometer
{
public:
	PowerManager();
	~PowerManager();

	RainGauge rg =  RainGauge();
	Thermometer tm = Thermometer();
	Anemometer am = Anemometer();
	Barometer bm = Barometer();
	Hygrometer hm = Hygrometer();

	bool isOn;
	bool isOff;

	void Reboot();
	void PowerOFF();
	void PowerON();
	void Suspend();
	void Overload();
	void EnableUpdate();
	void DisableUpdate();
};

