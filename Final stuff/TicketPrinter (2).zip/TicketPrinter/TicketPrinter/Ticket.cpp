#include "stdafx.h"
#include "Ticket.h"


Ticket::Ticket()
{
}


Ticket::~Ticket()
{
}

void Ticket::PriceCalc()
{

}

void Ticket::AddTicket()
{

}

void Ticket::TicketType()
{

}

void Ticket::OneWay()
{

}

void Ticket::RoundTrip()
{

}

void Ticket::AgeOfTraveler()
{

}

void Ticket::ETA()
{

}