#include "stdafx.h"
#include "Cash.h"


Cash::Cash()
{
}


Cash::~Cash()
{
}

void Cash::ValidateAmount()
{
	cout << "" << endl;
}