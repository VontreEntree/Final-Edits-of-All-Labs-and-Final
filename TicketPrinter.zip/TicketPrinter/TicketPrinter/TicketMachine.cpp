#include "stdafx.h"
#include "TicketMachine.h"


TicketMachine::TicketMachine()
{
}


TicketMachine::~TicketMachine()
{
}

void TicketMachine::ValidateTrip()
{

}

void TicketMachine::Finalize()
{

}

void TicketMachine::PrintTicket()
{

}