#include <iostream>
#include <string>

using namespace std;

#pragma once
class Cash
{
public:
	Cash();
	~Cash();

	void ValidateAmount();
};

